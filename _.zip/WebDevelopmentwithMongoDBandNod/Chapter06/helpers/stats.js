module.exports = function() {
    var stats = {
        images:     0,
        comments:   0,
        views:      0,
        likes:      0
    };

    return stats;
};
