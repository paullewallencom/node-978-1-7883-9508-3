// const request = require('request'),
// 	sinon = require("sinon"),
// 	log = sinon.spy();

 
// module.exports =()=>{ 
//     request('http://www.google.com', (err, res, body)=>{ 
//         log(body); 
//     }); 
// }